package br.edu.qi.view;

import java.text.SimpleDateFormat;

import br.edu.qi.model.Pessoa;

public class TelaDetalhePessoa {

	private Pessoa pessoa;
	public TelaDetalhePessoa(Pessoa p) {
		this.pessoa=p;
	}
	public void mostraDados(){
		mostraDadosPessoa();
		mostraDetalheEndereco();
	}
	protected void mostraCabecalhoPesso(){
		System.out.println("------------------------------------");
		System.out.println("Dados da Pessoa");
		System.out.println("------------------------------------");

	}
	protected void mostraDadosPessoa() {
		System.out.println("C�digo: " + this.pessoa.getCodigo());
		System.out.println("Nome: " + this.pessoa.getNome());
		System.out.println("Sexo: " + this.pessoa.getSexo());
		System.out.println("Data Nasc.: " + new SimpleDateFormat("dd/MM/yyyy").format(this.pessoa.getDataNascimento()));
		

	}
	protected void mostraDetalheEndereco(){
		System.out.println("------------------------------------");
		TelaDetalheEndereco endereco = new TelaDetalheEndereco(this.pessoa.getEndereco());
		endereco.mostraDados();
	}
	protected Pessoa getPessoa(){
		return this.pessoa;
	}
}
