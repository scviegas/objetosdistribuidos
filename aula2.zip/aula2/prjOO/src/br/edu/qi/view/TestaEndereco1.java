package br.edu.qi.view;

import br.edu.qi.model.Endereco;

public class TestaEndereco1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Endereco endereco = new Endereco("Rua x",23,"apto 22","Centro","94.930-120");
		System.out.println(endereco.toString());
		

	}

}
