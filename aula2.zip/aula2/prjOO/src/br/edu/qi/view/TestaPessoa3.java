package br.edu.qi.view;

public class TestaPessoa3 {

	public static void main(String[] args) {
		
	}
}
