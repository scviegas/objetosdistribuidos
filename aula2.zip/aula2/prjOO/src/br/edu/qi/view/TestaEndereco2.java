package br.edu.qi.view;

import br.edu.qi.model.Endereco;

public class TestaEndereco2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Endereco endereco = new Endereco("Rua Teres�polis", 
				 685, "casa", "Parque da Matriz", "94.950-100");
		
		TelaDetalheEndereco detalhe = new TelaDetalheEndereco(endereco);
		
		detalhe.mostraDados();
		
		
	}

}
