package br.edu.qi.view;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import br.edu.qi.model.Pessoa;

public class TestaPessoa1 {

	/**
	 * @param args
	 * @throws ParseException 
	 */
	public static void main(String[] args) throws ParseException {

		Pessoa pessoa = new Pessoa();
		
		pessoa.setCodigo(100);
		pessoa.setNome("Rodrigo");
		pessoa.setSexo('M');
		pessoa.setDataNascimento(new SimpleDateFormat("dd/MM/yyyy").parse("07/10/1974"));
	   
		System.out.println("---------------------");
		System.out.println("Codigo="+pessoa.getCodigo());
		System.out.println("DataNasc.:"+new SimpleDateFormat("dd/MM/yyyy").format(pessoa.getDataNascimento()));
		System.out.println("Sexo:"+pessoa.getSexo());
	}

}
