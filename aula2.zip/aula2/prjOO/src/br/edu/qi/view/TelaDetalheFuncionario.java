package br.edu.qi.view;

import br.edu.qi.model.Funcionario;

public class TelaDetalheFuncionario extends TelaDetalhePessoa {

	public TelaDetalheFuncionario(Funcionario f) {
		super(f);
		
	}
	
	@Override
	public void mostraDados() {
		super.mostraCabecalhoPesso();
		super.mostraDadosPessoa();
		System.out.println("Sal�rio :"+((Funcionario)super.getPessoa()).getSalario());
		System.out.println("Estado civil: "+((Funcionario)super.getPessoa()).getEstadoCivil());
		super.mostraDetalheEndereco();
	}
	
}
