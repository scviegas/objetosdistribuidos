package br.edu.qi.view;


import java.text.ParseException;
import java.text.SimpleDateFormat;

import br.edu.qi.model.Endereco;
import br.edu.qi.model.EstadoCivil;
import br.edu.qi.model.Funcionario;

public class TestaFuncionario1 {

	/**
	 * @param args
	 * @throws ParseException 
	 */
	public static void main(String[] args) throws ParseException {

		Funcionario func = new Funcionario();
	
		Endereco ender = new Endereco("Rua C",234,"Casa","centro", "94.954-100");
		
		func.setCodigo(100);
		func.setCpf("690.430.200-03");
		func.setDataNascimento(new SimpleDateFormat("dd/MM/yyyy").parse("07/10/1974"));
		func.setEndereco(ender);
		func.setEstadoCivil(EstadoCivil.CASADO);
		func.setNome("Rodrigo");
		func.setSalario(8000.00);
		func.setSexo('M');
		
		TelaDetalheFuncionario detalheFunc = new TelaDetalheFuncionario(func);
		detalheFunc.mostraDados();
		
	}

}
