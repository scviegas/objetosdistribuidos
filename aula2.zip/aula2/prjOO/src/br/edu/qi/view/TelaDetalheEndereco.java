package br.edu.qi.view;

import br.edu.qi.model.Endereco;

public class TelaDetalheEndereco {

	private Endereco endereco;

	public TelaDetalheEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public void mostraDados() {
		
		System.out.println("Dados do Endere�o");
		System.out.println("------------------------------------");
		System.out.println("Rua: " + this.endereco.getRua());
		System.out.println("N�mero: " + this.endereco.getNumero());
		System.out.println("Compl.: " + this.endereco.getComplemento());
		System.out.println("Bairro: " + this.endereco.getBairro());
		System.out.println("Cep: " + this.endereco.getCep());
		System.out.println("------------------------------------");

	}
}
