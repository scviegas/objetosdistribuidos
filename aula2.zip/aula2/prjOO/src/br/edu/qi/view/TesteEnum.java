package br.edu.qi.view;

import br.edu.qi.model.EstadoCivil;

public class TesteEnum {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		System.out.println(EstadoCivil.SOLTEIRO);
		if (EstadoCivil.SOLTEIRO.equals(EstadoCivil.SOLTEIRO))
			System.out.println("verdadeito");

		// System.out.println(EstadoCivil.CASADO.geValue());

	}

}
