package br.edu.qi.view;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import br.edu.qi.model.Endereco;
import br.edu.qi.model.Pessoa;

public class TestaPessoa2 {

	/**
	 * @param args
	 * @throws ParseException 
	 */
	public static void main(String[] args) throws ParseException {

		Pessoa pessoa = new Pessoa();
		Endereco ender=null;
		
		pessoa.setCodigo(100);
		pessoa.setNome("Rodrigo");
		pessoa.setSexo('M');
		pessoa.setDataNascimento(new SimpleDateFormat("dd/MM/yyyy").parse("07/10/1974"));
		
		ender = new Endereco("Rua x",34,"casa","parque da matriz","94.950-100");
		pessoa.setEndereco(ender);
		TelaDetalheEndereco detalheEnder = new TelaDetalheEndereco(ender);
		detalheEnder.mostraDados();
		//System.out.println(pessoa.getEndereco().toString());
		
		
	}

}
