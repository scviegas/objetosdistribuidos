package br.edu.qi.model;

import java.util.Date;

public class Funcionario extends Pessoa {


	private double salario;
	private EstadoCivil estadoCivil;
	
	public Funcionario() {
	}
	public Funcionario(int c, String n, Date d,Endereco e){
		super(c,n,e);
		
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public EstadoCivil getEstadoCivil() {
		return estadoCivil;
	}
	public void setEstadoCivil(EstadoCivil estadoCivil) {
		this.estadoCivil = estadoCivil;
	}
	
}
