package br.edu.qi.model;

import java.util.Date;

public class Pessoa {

	private int codigo;
	private String nome;
	private char sexo;
	private Date dataNascimento;
	private Endereco endereco;
	private String cpf;
	
	public Pessoa() {
	}

	public Pessoa(int c, String n){
		this.codigo=c;
		this.nome=n;
	}
	public Pessoa(int c,String n, Endereco e){
		this.codigo=c;
		this.nome=n;
		this.endereco=e;
	}
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public Date getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getCpf() {
		return cpf;
	}
}
