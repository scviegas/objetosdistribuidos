package br.edu.qi.model;

public enum EstadoCivil {

	CASADO(1), SOLTEIRO(2), VIUVO(3);

	private final int valor;

	EstadoCivil(int vl) {
		valor = vl;
	}

}
