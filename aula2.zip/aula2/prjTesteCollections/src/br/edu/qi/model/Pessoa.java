package br.edu.qi.model;

public class Pessoa implements Comparable {

	private String nome;
	private int idade;
	
	public Pessoa(String nome, int idade) {
		this.nome = nome;
		this.idade = idade;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}

	

	public String toString() {
		return this.nome + " ," + String.valueOf(this.idade);
	}

	public int compareTo(Object obj) {
		
		Pessoa p = (Pessoa)obj;
		
		if (this.nome.compareTo(p.getNome()) != 0)
			return this.nome.compareTo(p.getNome());
		else
			return ((Integer)this.idade).compareTo(p.getIdade());
		
	}
	
}
