package br.edu.qi.model;

public class Endereco {

	private String rua;
	private int numero;

	public Endereco(String rua, int nro) {
		this.rua = rua;
		this.numero = nro;
	}
	public String toString() {
		return "Endereco [rua=" + rua + ", numero=" + numero + "]";
	}

	public String getRua() {
		return rua;
	}

	public void setRua(String rua) {
		this.rua = rua;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}
	
	
	
}
