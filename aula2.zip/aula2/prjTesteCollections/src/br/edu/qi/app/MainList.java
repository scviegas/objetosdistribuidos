package br.edu.qi.app;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import br.edu.qi.model.Pessoa;

public class MainList {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		List<Pessoa> lista = new ArrayList<Pessoa>();

		lista.add(new Pessoa("Rodrigo", 38));
		lista.add(new Pessoa("Marcelo", 43));
		lista.add(new Pessoa("Allan", 28));
		lista.add(new Pessoa("Marco", 30));

		System.out.println("--Lista na orde original---");
		for (Pessoa pessoa : lista) {
			System.out.println(pessoa.toString());
		}
			
		Collections.reverse(lista);
		
		System.out.println("--inverso---");
		for (Pessoa pessoa : lista) {
			System.out.println(pessoa.toString());
		}
		
		Collections.sort(lista);
		
		System.out.println("--ordem---");
		for (Pessoa pessoa : lista) {
			System.out.println(pessoa.toString());
		}
		
		System.out.println("---LINKEDLIST");
		System.out.println();
		
		List<Pessoa> lst = new LinkedList<Pessoa>();
		
		LinkedList<Pessoa> lista1 = new LinkedList<Pessoa>();

		lista1.push(new Pessoa("Rodrigo", 38));
		lista1.push(new Pessoa("Marcelo", 43));
		lista1.push(new Pessoa("Allan", 28));
		lista1.push(new Pessoa("Marco", 30));
		
		for (Pessoa pessoa : lista1) {
			System.out.println(pessoa.toString());
		}
		
		System.out.println("substituindo valor");
		
		lista1.set(2, new Pessoa("Willian Bonner", 45));
		for (Pessoa pessoa : lista1) {
			System.out.println(pessoa.toString());
		}
		
		
		
	}

}
