package br.edu.qi.app;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import br.edu.qi.model.Endereco;
import br.edu.qi.model.Pessoa;

public class MainMap {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Map<Integer,Pessoa> mapa1 = new HashMap<Integer,Pessoa>();
		
		mapa1.put(100, new Pessoa("Rodrigo", 38));
		mapa1.put(200, new Pessoa("Allan", 23));
		mapa1.put(300, new Pessoa("Miguel", 22));
		mapa1.put(400, new Pessoa("Lia", 33));
		
		System.out.println(mapa1);
		
		System.out.println("");
		System.out.println("--recupera 300--");
		System.out.println(mapa1.get(300));
		
		Map<Pessoa, Endereco> mapa = new HashMap<Pessoa,Endereco>();
		
		mapa.put(new Pessoa("Rodrigo", 38), new Endereco("Rua x",22));
		mapa.put(new Pessoa("Ronaldo", 33), new Endereco("Rua a",12));
		mapa.put(new Pessoa("Carla", 21), new Endereco("Rua x",22));
		mapa.put(new Pessoa("Carlos", 38), new Endereco("Rua ccc",343));
		
		System.out.println("");
		System.out.println(" mapas com Pessoas e Endere�os ");
		System.out.println();
		
		System.out.println(mapa);
		
		System.out.println(" listar as pessoas ");
		
		Set<Pessoa> pess = mapa.keySet();
		
		for (Pessoa pessoa : pess) {
			System.out.println(pessoa);
		}
		
	}

}
