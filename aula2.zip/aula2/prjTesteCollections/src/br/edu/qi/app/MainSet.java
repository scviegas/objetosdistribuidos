package br.edu.qi.app;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import br.edu.qi.model.Pessoa;

public class MainSet {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Set<Pessoa> lista = new HashSet<Pessoa>();

		lista.add(new Pessoa("Rodrigo", 38));
		lista.add(new Pessoa("Marcelo", 43));
		lista.add(new Pessoa("Allan", 28));
		lista.add(new Pessoa("Marco", 30));

		for (Pessoa pessoa : lista) {
			System.out.println(pessoa.toString());
		}

		System.out.println("--TreeSet---");
		Set<Pessoa> lista1 = new TreeSet<Pessoa>();

		lista1.add(new Pessoa("Rodrigo", 38));
		lista1.add(new Pessoa("Marcelo", 43));
		lista1.add(new Pessoa("Allan", 28));
		lista1.add(new Pessoa("Marco", 30));

		for (Pessoa pessoa : lista1) {
			System.out.println(pessoa.toString());
		}
	}

}
