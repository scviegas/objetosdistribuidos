/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desenv.oo.aula.pkg1.revenda.de.veículos.models;

import Entidades.Marca;
import Entidades.Veiculos.Veiculo;
import static desenv.oo.aula.pkg1.revenda.de.veículos.Main.marcas;
import static desenv.oo.aula.pkg1.revenda.de.veículos.Main.veiculos;
import java.util.ArrayList;

/**
 *
 * @author Aula Doo
 */
public class MarcaModel {

    /**
     * Retorna todas as marcas persistidas
     * @return 
     */
    public ArrayList<Marca> buscarTodasMarcas() {
        return marcas;
    }

    /**
     * Apaga uma marca filtrando pelo seu código cadastrado
     * @param codigoMarca 
     */
    public void deletarMarcaPorCodigo(int codigoMarca) {
        for (Marca marca : marcas) {
            if (marca.getCodigo() == codigoMarca) {
                
                for (Veiculo veiculo : veiculos) {
                    if (veiculo.getMarca()== marca) {
                        System.out.println("Impossível deletar marca"
                                + " associado a um veiculo.");
                        
                        return;
                    }
                }
                
                marcas.remove(marca);
                System.out.println("Marca " + marca.getNome() + " deletada com"
                + " sucesso!");
                return;
            }
        }
        
        System.out.println("Marca não encontrada!");
    }

    /**
     * Busca uma marca de acorod com seu código
     * @param codigo
     * @return 
     */
    public Marca buscarMarcaPorCodigo(int codigo) {
        for (Marca marca : marcas) {
            if (marca.getCodigo() == codigo) {
                return marca;
            }
        }
        
        return null;
    }
    
    /** 
     * Persiste uma nova marca
     * @param marca 
     */
    public void cadastrarMarcar(Marca marca) {
        marcas.add(marca);
    }
}
