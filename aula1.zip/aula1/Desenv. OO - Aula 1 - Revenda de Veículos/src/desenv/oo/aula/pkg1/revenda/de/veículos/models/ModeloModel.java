/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desenv.oo.aula.pkg1.revenda.de.veículos.models;

import Entidades.Modelo;
import Entidades.Veiculos.Veiculo;
import static desenv.oo.aula.pkg1.revenda.de.veículos.Main.modelos;
import static desenv.oo.aula.pkg1.revenda.de.veículos.Main.veiculos;
import java.util.ArrayList;

/**
 *
 * @author Aula Doo
 */
public class ModeloModel {

    public ArrayList<Modelo> buscarTodosModelos() {
        return modelos;
    }

    /**
     * Método reponsável por apagar um modelo de veículo filtrando 
     * pelo seu código
     * @param codigoModelo 
     */
    public void deletarModeloPorCodigo(int codigoModelo) {
        for (Modelo modelo : modelos) {
            if (modelo.getCodigo() == codigoModelo) {
                
                for (Veiculo veiculo : veiculos) {
                    if (veiculo.getModelo() == modelo) {
                        System.out.println("Impossível deletar modelo"
                                + " associado a um veiculo.");
                        
                        return;
                    }
                }
                
                modelos.remove(modelo);
                System.out.println("Modelo " + modelo.getNome() 
                        + " deletado com sucesso.");
                return;
            }
        }
        
        System.out.println("Modelo não encontrado.");
    }

        /**
     * Busca um modelo de acorod com seu código
     * @param codigo
     * @return 
     */
    public Modelo buscarModeloPorCodigo(int codigo) {
        for (Modelo modelo : modelos) {
            if (modelo.getCodigo() == codigo) {
                return modelo;
            }
        }
        
        return null;
    }
    
    /**
     * Método responsável por cadastrar um novo modelo de veículo
     * @param modelo 
     */
    public void cadastrarModelo(Modelo modelo) {
        modelos.add(modelo);
    }
    
}
