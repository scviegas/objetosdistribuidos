/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desenv.oo.aula.pkg1.revenda.de.veículos;

import Entidades.Elements.VeiculoTipoEnum;
import Entidades.Marca;
import Entidades.Modelo;
import Entidades.Veiculos.Carro;
import Entidades.Veiculos.Moto;
import Entidades.Veiculos.Veiculo;
import desenv.oo.aula.pkg1.revenda.de.veículos.controllers.HomeController;
import java.util.ArrayList;

/**
 *
 * @author Aula Doo
 */
public class Main {

    public static ArrayList<Veiculo> veiculos = new ArrayList<>();
    
    public static ArrayList<Marca> marcas = new ArrayList<>();
    
    public static ArrayList<Modelo> modelos = new ArrayList<>();
        
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Main.startUp();
        HomeController home = new HomeController();
        home.index();
    }
    
    /**
     * Método responsável por inserir alguns dados pré-definidos
     */
    private static void startUp()
    {
        marcas.add(new Marca(1111, "Chevrolet"));
        marcas.add(new Marca(2222, "Volkswagem"));
        marcas.add(new Marca(3333, "Ford"));
        marcas.add(new Marca(4444, "Harley"));
        
        modelos.add(new Modelo(111111, "Opala SS"));
        modelos.add(new Modelo(111112, "Camaro"));
        modelos.add(new Modelo(222221, "Golf"));
        modelos.add(new Modelo(222222, "Gol"));
        modelos.add(new Modelo(333331, "Fusin"));
        modelos.add(new Modelo(333332, "Edge"));
        modelos.add(new Modelo(444441, "Sportster"));
        modelos.add(new Modelo(444442, "Fat Boy FL"));
        modelos.add(new Modelo(444443, "V-ROD Musc"));

        veiculos.add(new Carro(
                marcas.get(0),
                modelos.get(0),
                VeiculoTipoEnum.CARRO,
                15000,
                1980,
                true,
                111111111,
                2,
                "Pneus banda branca"
        ));
        
        veiculos.add(new Carro(
                marcas.get(2),
                modelos.get(4),
                VeiculoTipoEnum.CARRO,
                60500,
                2015,
                true,
                333332311,
                4,
                "Teto solar"
        ));
        
        veiculos.add(new Moto(
                marcas.get(3),
                modelos.get(6),
                VeiculoTipoEnum.MOTO,
                50000,
                2014,
                true,
                444441141,
                1200,
                "Harley Turbo"
        ));
    }
}
